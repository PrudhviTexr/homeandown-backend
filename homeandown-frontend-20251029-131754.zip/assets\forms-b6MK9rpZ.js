import"./vendor-BbfL4SXj.js";

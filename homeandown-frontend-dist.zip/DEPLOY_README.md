# Frontend Deployment for GoDaddy

## Quick Deploy Instructions

### Step 1: Update Backend URL (if needed)

If you deployed the backend to a different URL than `https://homeandown-backend.onrender.com`, edit the `.env.production` file before uploading.

### Step 2: Upload All Files

1. Login to GoDaddy cPanel
2. Open File Manager
3. Navigate to your domain's `public_html` folder (or your site folder)
4. Upload ALL files from this `dist` folder
5. Make sure `index.html` is in the root directory

### Step 3: Verify

Visit your domain - it should show the Home & Own website!

## Important Notes

- The backend URL is set to: `https://homeandown-backend.onrender.com`
- The frontend automatically detects production vs development
- Cookies and authentication work automatically
- API calls will go to your Render backend

## Backend Setup Required

Make sure your backend is deployed to Render.com:
1. Go to https://render.com
2. Connect the GitHub repo: https://github.com/PrudhviTexr/homeandown-backend
3. Deploy the Python FastAPI application
4. Note the URL (usually: https://homeandown-backend.onrender.com)

## Database Migration

Don't forget to run this SQL in Supabase:
```sql
ALTER TABLE IF EXISTS public.documents
ADD COLUMN IF NOT EXISTS status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now(),
ADD COLUMN IF NOT EXISTS rejection_reason text;
```

## Troubleshooting

### 404 Errors
- Make sure all files are uploaded
- Check that `index.html` exists in the root folder

### API Errors  
- Verify your backend is running on Render
- Check the backend URL in browser console
- Make sure CORS is enabled on your backend

### Authentication Issues
- Ensure cookies are enabled
- Check that backend authentication endpoints are working

## Support

If you need help:
1. Check the console for errors (F12)
2. Verify backend is running
3. Check network tab for API calls
4. Review the backend logs on Render

